﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6212_POE.Classes
{
    public class IngredientInfo
    {
        public string Name { get; }
        private double OriQuantity; // Store the original quantity value
        private int OriCalories; // Store the original calories value
        public double Quantity { get; set; }
        public string Unit { get; }
        public int Calories { get; set; } // Now we can set the calories value
        public string FoodGroup { get; }


        public IngredientInfo(string name, double quantity, string unit, int calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            OriQuantity = quantity; // Store the original quantity value
            Unit = unit;
            Calories = calories;
            OriCalories = calories; // Store the original calories value
            FoodGroup = foodGroup;
        }

        // Reset the quantity and the calories to their original values
        public void ResetQuantityAndCalories()
        {
            Quantity = OriQuantity;
            Calories = OriCalories;
        }
    }
}
