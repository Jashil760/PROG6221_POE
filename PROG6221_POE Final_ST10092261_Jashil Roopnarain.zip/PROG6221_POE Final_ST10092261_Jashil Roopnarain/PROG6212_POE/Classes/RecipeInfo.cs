﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PROG6212_POE.Classes
{
    public class RecipeInfo
    {
        public delegate void ExceededCaloriesHandler();
        public event ExceededCaloriesHandler ExceededCalories;

        public string Name { get; }
        public List<IngredientInfo> Ingredients { get; }
        public List<string> Description { get; }

        public RecipeInfo(string name, List<IngredientInfo> ingredients, List<string> desc)
        {
            Name = name;
            Ingredients = ingredients;
            Description = desc;
        }

        // Get the details of the recipe
        public string GetRecipeDetails()
        {
            string details = $"Recipe: {Name}\n\nIngredients:\n";

            foreach (IngredientInfo ingredient in Ingredients)
            {
                details += $"{ingredient.Name}: {ingredient.Quantity} {ingredient.Unit}\n";
            }

            details += "\nStep Description:\n";

            for (int i = 0; i < Description.Count; i++)
            {
                details += $"{i + 1}. {Description[i]}\n";
            }

            return details;
        }

        // Calculate the total calories
        public int GetTotalCalories()
        {
            int totalCalories = 0;

            foreach (IngredientInfo ingredient in Ingredients)
            {
                totalCalories += ingredient.Calories;
            }

            // Notify if the recipe exceeds a certain calorie count
            if (totalCalories > 300 && ExceededCalories != null)
            {
                ExceededCalories();
            }

            return totalCalories;
        }

        // Scale the recipe
        public void ScaleRecipe(double scale)
        {
            foreach (IngredientInfo ingredient in Ingredients)
            {
                ingredient.Quantity *= scale;
                ingredient.Calories = (int)Math.Round(ingredient.Calories * scale);
            }
        }

        // Reset the quantities
        public void ResetQuantities()
        {
            foreach (IngredientInfo ingredient in Ingredients)
            {
                ingredient.ResetQuantityAndCalories();
            }
        }

    }
}
