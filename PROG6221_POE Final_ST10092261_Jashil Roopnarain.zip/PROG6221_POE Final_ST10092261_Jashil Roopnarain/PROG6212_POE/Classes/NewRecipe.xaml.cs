﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace PROG6212_POE.Classes
{
    /// <summary>
    /// Interaction logic for NewRecipe.xaml
    /// </summary>
    public partial class NewRecipe : Window
    {
        public delegate void RecipeAddedEventHandler(object sender, RecipeInfo e);
        public event RecipeAddedEventHandler RecipeAdded;
        List<IngredientInfo> ing = new List<IngredientInfo>();

        string recipeName;
        string ingredientName;        
        int quantity;
        string Measurement;
        int calories;
        string foodGroup;        
        string description;
        
        List<string> desc = new List<string>();
        public NewRecipe()
        {
            InitializeComponent();
        }   

        private void continuebtn_Click(object sender, RoutedEventArgs e)
        {
            MainWindow gui = new MainWindow();
            gui.Show();
            this.Close();
        }

        private void addRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                recipeName = recipeNameText.Text;                
                ingredientName = nameIngredientText.Text;
                quantity = Convert.ToInt32(quantityText.Text);
                Measurement = measurementText.Text;
                calories = Convert.ToInt32(caloriesText.Text);
                foodGroup = foodGroupText.Text;

                // Create a new ingredient object
                IngredientInfo ingredient = new IngredientInfo(ingredientName, quantity, Measurement, calories, foodGroup);

                // Add this ingredient to the ingredients list
                ing.Add(ingredient);
            }
            catch (Exception)
            {
                MessageBox.Show("Please add numeric value in quantity and calories", "Error", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            // Combine the information
            string ingredientInfo = $"Name: {ingredientName}\n Quantity: {quantity}\n Unit: {Measurement}\n Calories: {calories}\n Food Group: {foodGroup}\n";

            // Add to the ListBox
            displaylist.Items.Add(ingredientInfo);

            // Clear the text boxes for the next input
            nameIngredientText.Clear();
            quantityText.Clear();
            measurementText.Clear();
            caloriesText.Clear();
            foodGroupText.Clear();            

            description = descriptionText.Text;
            desc.Add(description);
            // Add the step to the ListBox
            displaylist.Items.Add($"Step: {description}");

            // Clear the text box for the next step
            descriptionText.Clear();

            // Create the Recipe object with all the ingredients
            RecipeInfo recipe = new RecipeInfo(recipeName, ing, desc);

            // Invoke the event before closing the window
            RecipeAdded?.Invoke(this, recipe);
        }
    }
}
