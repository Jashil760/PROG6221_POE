﻿using PROG6212_POE.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PROG6212_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static List<Classes.RecipeInfo> rec = new List<Classes.RecipeInfo>();
        public MainWindow()
        {
            InitializeComponent();
            
        }
        private void NewRecipe_RecipeAdded(object sender, RecipeInfo e)
        {
            // Code to handle adding the recipe 
            // For example, you can add it to your recipes list:
            rec.Add(e);
            RefreshContent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
            RefreshContent();           
        }

        public void RefreshContent()
        {

            // Clear the existing items
            displayRecipecombo.Items.Clear();
            recipecombo.Items.Clear();
            resetcombo.Items.Clear();
            scalecombo.Items.Clear();
            

            // Sort recipes
            List<RecipeInfo> sortedRecipes = rec.OrderBy(r => r.Name).ToList();

            // Add scaling factors only if they are not already in the combo box
            if (scalecombo.Items.Count == 0)
            {
                scalecombo.Items.Add("0.5");
                scalecombo.Items.Add("2");
                scalecombo.Items.Add("3");
            }

            // HashSet to store unique ingredients and food groups
            HashSet<string> ingredients = new HashSet<string>();
            HashSet<string> foodGroups = new HashSet<string>();

            // Display the names of all the recipes and populate ingredients and food groups
            foreach (RecipeInfo recipe in sortedRecipes)
            {
                displayRecipecombo.Items.Add(recipe.Name);
                recipecombo.Items.Add(recipe.Name);
                resetcombo.Items.Add(recipe.Name);

                foreach (IngredientInfo ingredient in recipe.Ingredients)
                {
                    ingredients.Add(ingredient.Name);
                    foodGroups.Add(ingredient.FoodGroup); // assuming Ingredient has a FoodGroup property
                }
            }
            
            // Populate the ingredient filter combobox
            foreach (string ingredient in ingredients)
            {
                ingredientcombo.Items.Add(ingredient);
            }

            // Populate the food group filter combobox
            foreach (string foodGroup in foodGroups)
            {
                foodGroupcombo.Items.Add(foodGroup);
            }
        }

        private void newRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            NewRecipe newrecipe = new NewRecipe();
            newrecipe.RecipeAdded += NewRecipe_RecipeAdded;
            Classes.NewRecipe gui = new Classes.NewRecipe();
            gui.Show();
            this.Close();
        }

        private void closebtn_Click(object sender, RoutedEventArgs e)
        {
            Classes.CLoseRecipe gui = new Classes.CLoseRecipe();
            gui.Show();
            this.Close();
        }

        private void scaleRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            // Prompt for the name of the recipe to scale

            string recipeName = recipecombo.Text;

            // Find the selected recipe by its name
            RecipeInfo selectedRecipe = rec.Find(r => r.Name == recipeName);

            if (selectedRecipe != null)
            {
                // Prompt for the scaling factor

                double scale = Convert.ToDouble(scalecombo.Text);
                if ((scale == 0.5 || scale == 2 || scale == 3))
                {
                    displaylist.Items.Clear();
                    selectedRecipe.ScaleRecipe(scale);
                    MessageBox.Show("Successfully scaled the recipe", "Success", MessageBoxButton.OK, MessageBoxImage.Information);

                    return;
                }
                else
                {
                    MessageBox.Show("Invalid input. Scaling factor must be 0.5, 2, or 3.", "Error", MessageBoxButton.OK, MessageBoxImage.Information);
                }

                // Scale the selected recipe
                selectedRecipe.ScaleRecipe(scale);
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Recipe scaled successfully!");
                Console.ResetColor();
            }
        }

        private void resetRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            // Prompt for the name of the recipe to reset
            string recipeName = resetcombo.Text;

            // Find the selected recipe by its name
            RecipeInfo selectedRecipe = rec.Find(r => r.Name == recipeName);

            if (selectedRecipe != null)
            {
                // Reset the quantities of the ingredients in the selected recipe
                selectedRecipe.ResetQuantities();
                displaylist.Items.Clear();
                // Optional: Display a message indicating that the recipe has been reset.
                MessageBox.Show("The recipe has been reset.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            else
            {
                // Optional: Display a message indicating that the recipe was not found.
                MessageBox.Show("Recipe not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }

            // Optional: Refresh content to show the updated values.
            RefreshContent();
        }

        private void clearRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            // Clear the list that holds the recipes
            rec.Clear();

            // Clear the UI elements that display the recipes
            displaylist.Items.Clear();

            // Refresh the content to reflect the changes
            RefreshContent();

            // Optional: Display a message indicating that the recipes have been cleared.
            MessageBox.Show("All recipes have been cleared.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
        }        

        private void displayRecipebtn_Click(object sender, RoutedEventArgs e)
        {
            List<RecipeInfo> sortedRecipes = rec.OrderBy(r => r.Name).ToList();
            string recipeName = displayRecipecombo.Text;
            // Prompt for the name of the recipe to display
            RecipeInfo selectedRecipe = sortedRecipes.Find(r => r.Name == recipeName);

            if (selectedRecipe != null)
            {
                displaylist.Items.Add(selectedRecipe.GetRecipeDetails());
                displaylist.Items.Add($"Total Calories: {selectedRecipe.GetTotalCalories()}");

                if (selectedRecipe.GetTotalCalories() > 300)
                {
                    displaylist.Items.Add("Warning: The recipe exceeds 300 calories!");

                }
            }
        }

        private void foodGroupbtn_Click(object sender, RoutedEventArgs e)
        {
            string selectedIngredient = foodGroupcombo.Text; // Get the selected ingredient from the ComboBox.

            var filteredRecipes = rec.Where(recipe =>
                recipe.Ingredients.Any(ingredient => ingredient.FoodGroup == selectedIngredient)
            ).ToList();

            DisplayFilteredRecipes(filteredRecipes);
        }

        private void ingredientbtn_Click(object sender, RoutedEventArgs e)
        {
            string foodGroupName = ingredientcombo.Text; // Assuming this is a ComboBox where you select the food group.

            var filteredRecipes = rec.Where(recipe =>
                recipe.Ingredients.Any(ingredient => ingredient.Name == foodGroupName)
            ).ToList();

            DisplayFilteredRecipes(filteredRecipes);
        }

        private void maxCalbtn_Click(object sender, RoutedEventArgs e)
        {
            if (!rec.Any())
            {
                MessageBox.Show("There are no recipes to filter.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Find the maximum calories in the list of recipes.
            int maxCalories = rec.Max(recipe => recipe.GetTotalCalories());

            // Filter the recipes that have calories equal to this maximum value.
            var filteredRecipes = rec.Where(recipe => recipe.GetTotalCalories() == maxCalories).ToList();

            DisplayFilteredRecipes(filteredRecipes);
        }

        private void DisplayFilteredRecipes(List<RecipeInfo> filteredRecipes)
        {
            displaylist.Items.Clear(); // Assuming listShowAll is the ListBox to display recipes.

            if (filteredRecipes.Any())
            {
                foreach (var recipe in filteredRecipes)
                {
                    displaylist.Items.Add(recipe.GetRecipeDetails());
                }
            }
            else
            {
                displaylist.Items.Add("No recipes found.");
            }
        }
        private void displayList_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }

        
    }
    
}

